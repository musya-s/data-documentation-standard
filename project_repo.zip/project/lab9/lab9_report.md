# Лабораторная работа №9
Загрузка данных в PySpark и базовые операции.

## Результаты
- Загрузка CSV
- show(), printSchema()
- select(), filter(), orderBy()
- describe()
- Сохранение результатов в CSV
