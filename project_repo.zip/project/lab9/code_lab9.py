from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Lab9").getOrCreate()

df = spark.read.csv("data/students.csv", header=True, inferSchema=True)
df.show()
df.printSchema()
df.select("name", "grade").show()
df.filter(df.grade > 80).show()
df.orderBy("grade", ascending=False).show()
df.describe().show()

df.write.csv("data/result_lab9", header=True)
