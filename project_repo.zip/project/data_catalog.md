# Каталог данных

## students.csv
student_id — int  
name — string  
subject — string  
grade — int  

## students_info.csv
student_id — int  
age — int  
group — string  

## result_lab10/
Результаты агрегации PySpark
