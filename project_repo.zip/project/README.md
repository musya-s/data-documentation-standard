# Учебный проект по PySpark
Документация и результаты лабораторных работ №9 и №10

## Описание проекта
Проект включает загрузку данных в PySpark, базовые операции DataFrame,
агрегации, группировки и объединения таблиц.

## Структура
lab9/ — ЛР9  
lab10/ — ЛР10  
data/ — данные  
notebooks/ — ноутбуки  
README.md — документация  
data_catalog.md — описание данных

## Как запустить
pip install -r requirements.txt
python lab9/code_lab9.py
python lab10/code_lab10.py

## Автор
Муслим Сыдыкжанов
