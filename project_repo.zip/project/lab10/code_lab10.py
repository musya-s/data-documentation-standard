from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder.appName("Lab10").getOrCreate()

df = spark.read.csv("data/students.csv", header=True, inferSchema=True)
df2 = spark.read.csv("data/students_info.csv", header=True, inferSchema=True)

grouped = df.groupBy("subject").agg(
    F.count("*").alias("count"),
    F.avg("grade").alias("avg_grade")
)
grouped.show()

joined = df.join(df2, on="student_id", how="inner")
joined.show()

grouped.write.csv("data/result_lab10", header=True)
